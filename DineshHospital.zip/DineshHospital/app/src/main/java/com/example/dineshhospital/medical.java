package com.example.dineshhospital;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class medical extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical);
    }
}