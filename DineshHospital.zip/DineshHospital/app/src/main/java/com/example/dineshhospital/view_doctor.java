package com.example.dineshhospital;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class view_doctor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_doctor);
    }
}