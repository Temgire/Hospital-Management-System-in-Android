package com.example.dineshhospital;

import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

public class Doctorspage extends AppCompatActivity {
    FirebaseFirestore firestore ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctorspage);

        firestore = FirebaseFirestore.getInstance();

        firestore.collection("Patient Info").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                for (DocumentChange documentChange : value.getDocumentChanges()) {

                    Log.d("tag" ,documentChange.getDocument().getData().get("Patient Name").toString() ) ;
                    Log.d("tag" ,documentChange.getDocument().getData().get("Symtoms").toString() ) ;
                    Log.d("tag" ,documentChange.getDocument().getData().get("Time").toString() ) ;
                    Log.d("tag" ,documentChange.getDocument().getData().get("Date").toString() ) ;

                }
            }
        });
    }
}